import pandas as pd
import numpy as np
import os
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import skfuzzy as fuzz

# ==============================
# 1. Cargar dataset
# ==============================
df = pd.read_excel("DEMALE-HSJM_2025_data.xlsx")

# Eliminar filas con valores vacíos
df = df.dropna()

# ==============================
# 2. Definir variable objetivo y predictoras
# ==============================
y = df["diagnosis"]
X = df.drop(columns=["diagnosis"])

# ==============================
# 3. Codificar variables categóricas
# ==============================
for col in X.columns:
    if X[col].dtype == "object":
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))

# ==============================
# 4. Normalizar variables numéricas
# ==============================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==============================
# 5. Dividir en entrenamiento y prueba
# ==============================
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Crear carpeta de modelos
os.makedirs("models", exist_ok=True)

# ==============================
# 6. MODELO 1 - Regresión Logística
# ==============================
print("Entrenando Regresión Logística...")
log_model = LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=1000)
log_model.fit(X_train, y_train)
pickle.dump(log_model, open("models/logistic_model.pkl", "wb"))
print("✅ logistic_model.pkl guardado")

# ==============================
# 7. MODELO 2 - Red Neuronal Artificial
# ==============================
print("Entrenando Red Neuronal...")
nn_model = MLPClassifier(hidden_layer_sizes=(64, 32), activation='relu', solver='adam', max_iter=1000, random_state=42)
nn_model.fit(X_train, y_train)
pickle.dump(nn_model, open("models/neural_model.pkl", "wb"))
print("✅ neural_model.pkl guardado")

# ==============================
# 8. MODELO 3 - Máquina de Vectores de Soporte (SVM)
# ==============================
print("Entrenando SVM...")
svm_model = SVC(kernel='rbf', probability=True)
svm_model.fit(X_train, y_train)
pickle.dump(svm_model, open("models/svm_model.pkl", "wb"))
print("✅ svm_model.pkl guardado")

# ==============================
# 9. MODELO 4 - Mapas Cognitivos Difusos (Fuzzy C-Means)
# ==============================
print("Entrenando Mapa Cognitivo Difuso (Fuzzy C-Means)...")
n_clusters = len(np.unique(y_train))
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
    X_train.T, c=n_clusters, m=2, error=0.005, maxiter=1000, init=None
)

fcm_model = {
    "centers": cntr,
    "fpc": fpc,
    "scaler": scaler
}
pickle.dump(fcm_model, open("models/fcm_model.pkl", "wb"))
print("✅ fcm_model.pkl guardado")

# ==============================
# 10. Evaluación rápida
# ==============================
print("\n--- RESULTADOS ---")
for name, model in [("Regresión Logística", log_model),
                    ("Red Neuronal", nn_model),
                    ("SVM", svm_model)]:
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print(f"{name}: {acc:.2f}")

print("Entrenamiento completado con éxito ✅")
