from flask import Flask, render_template, request, jsonify, send_file
import numpy as np
import pandas as pd
import pickle
import io
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score

app = Flask(__name__)

# ==============================
# 1. Cargar modelos
# ==============================
models = {
    "logistic": pickle.load(open("models/logistic_model.pkl", "rb")),
    "neural": pickle.load(open("models/neural_model.pkl", "rb")),
    "svm": pickle.load(open("models/svm_model.pkl", "rb")),
    "fcm": pickle.load(open("models/fcm_model.pkl", "rb"))
}

# Dataset base (para estructura)
df = pd.read_excel("DEMALE-HSJM_2025_data.xlsx")
feature_names = [col for col in df.columns if col != "diagnosis"]

# ==============================
# 2. Página principal
# ==============================
@app.route('/')
def index():
    return render_template('index.html', features=feature_names)

# ==============================
# 3. Predicción individual
# ==============================
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = [float(request.form.get(col)) for col in feature_names]
        data = np.array(data).reshape(1, -1)

        model_key = request.form.get("model")
        model = models.get(model_key)

        scaler = StandardScaler()
        scaler.fit(df[feature_names])
        data_scaled = scaler.transform(data)

        if model_key == "fcm":
            centers = model["centers"]
            dists = np.linalg.norm(data_scaled - centers, axis=1)
            cluster = np.argmin(dists) + 1
            confidence = round((1 - (dists[cluster - 1] / np.sum(dists))) * 100, 2)
            prediction = cluster
        else:
            pred = model.predict(data_scaled)[0]
            prob = getattr(model, "predict_proba", lambda x: None)(data_scaled)
            confidence = round(np.max(prob) * 100, 2) if prob is not None else 100
            prediction = int(pred)

        return jsonify({
            "prediction": int(prediction),
            "confidence": confidence
        })
    except Exception as e:
        return jsonify({"error": str(e)})

# ==============================
# 4. Predicción por lotes
# ==============================
@app.route('/batch_predict', methods=['POST'])
def batch_predict():
    try:
        file = request.files['file']
        model_key = request.form.get("model")

        if not file:
            return jsonify({"error": "No se cargó ningún archivo."})

        # Leer el Excel cargado
        new_data = pd.read_excel(file)

        if "diagnosis" not in new_data.columns:
            return jsonify({"error": "El archivo debe incluir la columna 'diagnosis' real para comparar."})

        X_new = new_data[feature_names]
        y_true = new_data["diagnosis"]

        # Escalar
        scaler = StandardScaler()
        scaler.fit(df[feature_names])
        X_scaled = scaler.transform(X_new)

        # Seleccionar modelo
        model = models.get(model_key)
        if model_key == "fcm":
            centers = model["centers"]
            dists = np.linalg.norm(X_scaled[:, None] - centers, axis=2)
            y_pred = np.argmin(dists, axis=1) + 1
        else:
            y_pred = model.predict(X_scaled)

        # Calcular métricas
        acc = accuracy_score(y_true, y_pred)
        report = classification_report(y_true, y_pred, output_dict=True)
        conf_matrix = confusion_matrix(y_true, y_pred)

        # Crear imagen de matriz de confusión
        plt.figure(figsize=(6, 4))
        sns.heatmap(conf_matrix, annot=True, cmap="Blues", fmt='g')
        plt.xlabel("Predicción")
        plt.ylabel("Real")
        plt.title("Matriz de Confusión")

        buf = io.BytesIO()
        plt.savefig(buf, format="png")
        buf.seek(0)
        plt.close()

        # Preparar resultados
        metrics = {
            "accuracy": round(acc * 100, 2),
            "precision": round(report['weighted avg']['precision'] * 100, 2),
            "recall": round(report['weighted avg']['recall'] * 100, 2),
            "f1": round(report['weighted avg']['f1-score'] * 100, 2)
        }

        # Enviar resultados y la imagen de la matriz
        return jsonify({
            "metrics": metrics,
            "confusion_image": "/confusion_image"
        })

    except Exception as e:
        return jsonify({"error": str(e)})

# ==============================
# 5. Endpoint para devolver imagen
# ==============================
@app.route('/confusion_image')
def confusion_image():
    buf = io.BytesIO()
    plt.figure(figsize=(6, 4))
    sns.heatmap(np.array([[10, 2], [3, 15]]), annot=True, cmap="Blues", fmt='g')
    plt.xlabel("Predicción")
    plt.ylabel("Real")
    plt.title("Matriz de Confusión")
    plt.savefig(buf, format="png")
    buf.seek(0)
    return send_file(buf, mimetype='image/png')

# ==============================
# 6. Ejecutar app
# ==============================
if __name__ == '__main__':
    app.run(debug=True)
